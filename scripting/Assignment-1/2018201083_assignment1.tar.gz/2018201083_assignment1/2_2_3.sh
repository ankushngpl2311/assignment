sed -n '/\/198./p' address-book.csv | wc -l


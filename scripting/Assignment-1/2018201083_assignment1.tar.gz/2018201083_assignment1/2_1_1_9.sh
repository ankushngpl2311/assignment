sed -n  "/^\([A-Za-z]\).*\1$/p"  /usr/share/dict/words


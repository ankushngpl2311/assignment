sed -ne 's/[0-9]/?/g' -e 's/[,.]/*/gp' address-book.csv

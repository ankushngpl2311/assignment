sed -n "/.*'.*/p"  /usr/share/dict/words

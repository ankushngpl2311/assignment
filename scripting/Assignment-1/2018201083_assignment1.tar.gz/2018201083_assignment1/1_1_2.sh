grep "^[aeiou].*" /usr/share/dict/words | wc -l

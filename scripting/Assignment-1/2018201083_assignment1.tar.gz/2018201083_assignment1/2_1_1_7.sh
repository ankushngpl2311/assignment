 sed -n "/.\{20,\}/p"  /usr/share/dict/words


grep  "^[^A-Z]\{5\}$\|^[^A-Z]\{10\}$"  /usr/share/dict/words


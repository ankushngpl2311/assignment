ls -l | grep -c "^d"

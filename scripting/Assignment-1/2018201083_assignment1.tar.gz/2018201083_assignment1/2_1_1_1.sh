sed -n '/India\|Africa/p' /usr/share/dict/words


grep  "^\([A-Za-z]\).*\1$"  /usr/share/dict/words


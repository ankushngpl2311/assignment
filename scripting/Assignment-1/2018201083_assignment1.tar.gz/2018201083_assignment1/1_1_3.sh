grep "^[aeiou].*[aeiou]$" /usr/share/dict/words


sed -n "/^[A-Z]/p"  /usr/share/dict/words 

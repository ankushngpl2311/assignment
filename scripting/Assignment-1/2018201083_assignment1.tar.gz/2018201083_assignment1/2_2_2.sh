sed '/^[aeiouAEIOU]/d' address-book.csv


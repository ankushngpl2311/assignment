awk 'END{print}' marks.txt

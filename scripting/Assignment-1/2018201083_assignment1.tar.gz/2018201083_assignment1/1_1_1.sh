grep "India\|Africa" /usr/share/dict/words

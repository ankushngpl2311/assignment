grep ".*'.*"  /usr/share/dict/words


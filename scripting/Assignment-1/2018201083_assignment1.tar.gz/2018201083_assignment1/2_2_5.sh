sed -n 's/\([a-zA-Z]*,\)\([a-zA-Z]*,\)/\2\1/p' address-book.csv

sed -n '/a\{2,\}/p' /usr/share/dict/words

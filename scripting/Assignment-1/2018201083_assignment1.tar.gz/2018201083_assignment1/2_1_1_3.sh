sed -n '/^[aeiou].*[aeiou]$/p' /usr/share/dict/words

grep "a\{2,\}" /usr/share/dict/words


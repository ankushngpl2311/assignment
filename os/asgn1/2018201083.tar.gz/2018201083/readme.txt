
***********************************************************************************************
                          README
                  ANKUSH NAGPAL (ROll no 2018201083)

***********************************************************************************************


Project start with ./homepage
homepage.cpp has main() function
Normal mode
1)QUIT
  press 'q' to quit
2)to command mode
  press ':' to command mode



Command mode-  
1)create_file <source files> <destination> or create_dir
  a)Specify source and destination  in single quote.
     ex - create_file 'file 1.txt'  'directory'
         create_file '
  
  b)Destination path has to be absolute path w.r.t root of the application
  
  c) '.' can be specified as current working directory for destination path.

   There can be a space character in file name as shown in example above.

2)rename <file1/dir1> <file2/dir2>
  
  a) paths to be specified in single quote.
     example = rename 'file1.txt'  'file2.txt'

  b)paths has to be absolute w.r.t root of the application.


3)move <source> <destination>

   a) paths to be specified in single quote.
     example = rename 'file1.txt'  'file2.txt'

   b)paths has to be absolute w.r.t root of the application.

4) goto <path>

  a) a) paths to be specified in single quote.
     example = goto '/flow'

  b)path has to be starting with '/' representing root of the application.


5)Arrow keys are not implemented in command mode so dont press them.

6)to normal mode
  press "ESC" key to turn to normal mode






MAKEFILE

1) make clear 
  to clear object files and executables
2)make
 to build project













